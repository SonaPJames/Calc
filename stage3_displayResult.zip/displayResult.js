
function displayResult(resultData) {
    const resultElement = document.getElementById('result');
    if (resultData.error) {
        resultElement.textContent = resultData.error;
    } else {
        const { num1, operation, num2 } = getUserInput();
        resultElement.textContent = `The random result for ${num1} ${operation} ${num2} is: ${resultData.result}`;
    }
}
