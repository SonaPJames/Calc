
function calculate() {
    const inputData = getUserInput();          // Stage 1: Input
    const resultData = calculateResult(inputData); // Stage 2: Calculation
    displayResult(resultData);                 // Stage 3: Output
}
