
function calculateResult({ num1, operation, num2 }) {
    if (isNaN(num1) || isNaN(num2)) {
        return { error: 'Please enter valid numbers.' };
    }

    if (!['+', '-', '*', '/'].includes(operation)) {
        return { error: 'Invalid operation. Please use one of +, -, *, /.' };
    }

    const randomResult = (Math.random() * 2000 - 1000).toFixed(2);
    return { result: randomResult };
}
